package edu.wctc;

import java.util.ArrayList;
import java.util.List;

public class PaintCalculator {

    private List<Room> roomList = new ArrayList<>();

    public void addRoom (double length, double width, double height){
        Room room = new Room (width, length, height);
        roomList.add(room);
    }

    @Override
    public String toString() {
        String outPut = "";
//        return "";
        if (roomList.size() == 0){
            return "No Rooms Currently";
        }else {
            for (int x=0; x< roomList.size(); x++){
                Room r = roomList.get(x);
                outPut = outPut.concat("The Rooms area is" + r.toString()+ "\n");
            }
            return outPut;
        }

    }
}
