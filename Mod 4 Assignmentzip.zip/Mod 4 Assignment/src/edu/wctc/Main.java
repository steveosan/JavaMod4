package edu.wctc;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static Scanner sc = new Scanner(System.in);
    private static PaintCalculator PaintCalulater=new PaintCalculator();
    PrintWriter outputFile =new PrintWriter("Data.txt");

    public Main() throws FileNotFoundException {
    }

    public static void main(String[] args) throws IOException {


        printMenu();
        System.out.print("Enter Selection: ");
        int selectInput= sc.nextInt();

        while (selectInput < 5){
            if(selectInput == 1){
                createRoom();
                printMenu();
                System.out.print("Enter Selection: ");
                selectInput= sc.nextInt();
            }
            else if (selectInput == 2){

                String output=PaintCalulater.toString();
                System.out.println(output);
                printMenu();
                System.out.print("Enter Selection: ");
                selectInput= sc.nextInt();
            }
            else if(selectInput == 3){
                readFile();
                printMenu();
                System.out.print("Enter Selection: ");
                selectInput= sc.nextInt();
            }
            else if (selectInput == 4){
                writeFile();
                printMenu();
                System.out.print("Enter Selection: ");
                selectInput= sc.nextInt();

            }
        }
    }


    private static void printMenu() {
        System.out.println("Welcome to the RoOmaLiZeR!");
        System.out.println("##########################");
        System.out.println("1) Add a room");
        System.out.println("2) View Rooms");
        System.out.println("3) Read rooms from file");
        System.out.println("4) Write rooms to file");
        System.out.println("5) Quit Application");

    }
    private static double promptForDimension(String dimensionName){
        System.out.println("Please enter a " + dimensionName);
        double d = sc.nextDouble();
        return d;
    }

    private static void createRoom(){
        double width =0;
        double height=0;
        double length=0;
        String[] dimension={"width","height","lngth"};
        for (int x=0;x<=2;x++){
            if (x==0){
                width=promptForDimension(dimension[x]);
            }
            else if (x==1){
                height=promptForDimension(dimension[x]);
            }
            else {
                length=promptForDimension(dimension[x]);
            }
        }

        PaintCalulater.addRoom(length,width,height);
        System.out.println("Room created \n");
    }
    private static void readFile() throws FileNotFoundException {
        int x = 0;
        Scanner fileReader = new Scanner(new File("Data.txt"));
        List<String> fileData = new ArrayList<>();
        while (fileReader.hasNext()) {
            fileData.add(fileReader.nextLine());
            System.out.println(fileData.get(x));
            x++;
        }
    }
        private static void writeFile() throws FileNotFoundException {
            PrintWriter pw=new PrintWriter("Data.txt");
            String out=PaintCalulater.toString();
            pw.println(out);
            pw.flush();
            pw.close();
        }
    }



