package edu.wctc;

import java.util.ArrayList;
import java.util.List;

public class Room {
    private List <Wall> wallList = new ArrayList<>();

    public Room (double width, double length, double height){
        Wall wallOne = new Wall(width, height);
        wallList.add(wallOne);
        Wall wallTwo = new Wall(width, height);
        wallList.add(wallTwo);
        Wall wallThree = new Wall(length, height);
        wallList.add(wallThree);
        Wall wallFour = new Wall(length, height);
        wallList.add(wallFour);
    }

    public double getArea() {
        double area =0 ;

        for (int x=0; x< wallList.size(); x++){
            Wall w = wallList.get(x);
            area += w.getArea();
        }
        return area;
    }

    @Override
    public String toString() {
        return "" + getArea();
    }
}

